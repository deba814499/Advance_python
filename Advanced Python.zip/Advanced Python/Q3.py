s = input("Enter a String")

if s.isdigit():
    print("The system contains only digits")
else:
    print("The String doesn't contains all digits")