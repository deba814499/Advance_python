"""
1.WAP to take a string from user and print it in reverse.
2.WAP to count the number of uppercase and lowercase characters in a string.
3.WAP to check wheather a given string contains only digits.
4.WAP to replace all spaces in a string with underscore(_).
5.WAP to count the frequency of each character in a string. 
"""