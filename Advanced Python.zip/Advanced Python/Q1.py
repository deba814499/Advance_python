s = input("Enter a string: ")
reversed_string = s[::-1]
print("Reversed string:", reversed_string)
