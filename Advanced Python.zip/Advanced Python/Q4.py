s = input("Enter an String")

result = s.replace(" ","_")

print("The result is:",result)