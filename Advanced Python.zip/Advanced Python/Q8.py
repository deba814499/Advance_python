str1 = input("Enter first string: ")
str2 = input("Enter second string: ")

str1 = str1.replace(" ", "").lower()
str2 = str2.replace(" ", "").lower()

if len(str1) != len(str2):
    print("Not anagrams")
else:
    for ch in str1:
        if str1.count(ch) != str2.count(ch):
            print("Not anagrams")
            break
    else:
        print("The strings are anagrams")
